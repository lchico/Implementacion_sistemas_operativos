# os
Simple OS for ARM Cortex-M3/4 processors. Intended for learning.

To be used within https://github.com/pridolfi/workspace.
